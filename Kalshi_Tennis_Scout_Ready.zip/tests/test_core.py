import unittest
from datetime import datetime, timedelta, timezone
from tennis_core import (
    join_kalshi_espn, matchup_from_event, parse_espn_matches,
    matching_fixture, market_price, net_if_win, same_player,
)

NOW = datetime(2026, 11, 10, 15, 0, tzinfo=timezone.utc)


def kalshi_event():
    return {"ticker": "KXATPMATCH-TEST", "title": "Alcaraz vs Sinner", "markets": [
        {"ticker": "KXATPMATCH-TEST-ALC", "status": "active", "yes_sub_title": "Carlos Alcaraz", "yes_ask_dollars": "0.5800", "yes_bid_dollars": "0.5600"},
        {"ticker": "KXATPMATCH-TEST-SIN", "status": "active", "yes_sub_title": "Jannik Sinner", "yes_ask_dollars": "0.4500"},
    ]}


def espn_data(when, state="pre"):
    return {"events": [{"name": "ATP Finals", "groupings": [{"competitions": [{
        "id": "match1", "date": when.isoformat(),
        "status": {"type": {"state": state, "completed": state == "post"}},
        "competitors": [{"athlete": {"displayName": "C. Alcaraz"}},
                        {"athlete": {"displayName": "Jannik Sinner"}}]
    }]}]}]}


class Tests(unittest.TestCase):
    def test_names(self):
        self.assertTrue(same_player("Carlos Alcaraz", "C. Alcaraz"))
        self.assertTrue(same_player("Jannik Sinner", "Sinner"))
        self.assertFalse(same_player("Ben Shelton", "Taylor Fritz"))

    def test_quotes(self):
        event = matchup_from_event(kalshi_event())
        self.assertEqual(event["names"], ("Carlos Alcaraz", "Jannik Sinner"))
        self.assertEqual(market_price(event["markets"][0]), .58)
        self.assertAlmostEqual(net_if_win(.58, 10), 4.20)

    def test_single_binary_market(self):
        event = {"ticker": "KXATPMATCH-BINARY", "markets": [{
            "ticker": "KXATPMATCH-BINARY-YES", "status": "active",
            "yes_sub_title": "Jannik Sinner", "no_sub_title": "Carlos Alcaraz",
            "yes_ask_dollars": "0.45", "no_ask_dollars": "0.58",
        }]}
        x = matchup_from_event(event)
        self.assertIsNotNone(x)
        self.assertEqual(x["sides"], ("yes", "no"))
        self.assertEqual(market_price(x["markets"][1], x["sides"][1]), .58)
        fixture = parse_espn_matches(espn_data(NOW + timedelta(hours=3)), "ATP")
        matches = join_kalshi_espn({"ATP": [event]}, {"ATP": fixture}, NOW)
        self.assertEqual(matches[0]["sides"], ("no", "yes"))

    def test_invalid_market_excluded(self):
        event = kalshi_event()
        event["markets"][0]["status"] = "closed"
        self.assertIsNone(matchup_from_event(event))

    def test_future_match_accepted(self):
        fixture = parse_espn_matches(espn_data(NOW + timedelta(hours=3)), "ATP")
        matched = join_kalshi_espn({"ATP": [kalshi_event()]}, {"ATP": fixture}, NOW)
        self.assertEqual(len(matched), 1)
        self.assertEqual(matched[0]["names"], ("C. Alcaraz", "Jannik Sinner"))

    def test_started_or_uncertain_excluded(self):
        for when, state in ((NOW - timedelta(minutes=1), "pre"),
                            (NOW + timedelta(hours=2), "in"),
                            (NOW + timedelta(hours=2), "post"),
                            (NOW + timedelta(minutes=5), "pre")):
            fixtures = parse_espn_matches(espn_data(when, state), "ATP")
            self.assertEqual(len(join_kalshi_espn({"ATP": [kalshi_event()]},
                                                 {"ATP": fixtures}, NOW)), 0)

    def test_doubles_excluded(self):
        d = espn_data(NOW + timedelta(hours=2))
        d["events"][0]["groupings"][0]["competitions"][0]["competitors"][0]["athletes"] = [
            {"athlete": {"displayName": "A B"}}, {"athlete": {"displayName": "C D"}}]
        self.assertEqual(parse_espn_matches(d, "ATP"), [])

    def test_missing_schedule_not_invented(self):
        d = espn_data(NOW + timedelta(hours=2))
        del d["events"][0]["groupings"][0]["competitions"][0]["date"]
        self.assertEqual(parse_espn_matches(d, "ATP"), [])


if __name__ == "__main__":
    unittest.main()
